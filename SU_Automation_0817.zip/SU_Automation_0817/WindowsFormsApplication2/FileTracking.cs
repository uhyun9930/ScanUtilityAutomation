﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;
using System.Windows.Forms;

namespace ScanUtility_Automation
{
    class FileTracking : SU_Automation
    {

        //public delegate void mydele(Boolean FileState);
        //public event mydele view_event;
        public int num = 0;
        public string reName = "";
        System.Timers.Timer timerstimer = new System.Timers.Timer();
        public string fullPath;
        string path;
        string exe;
        
        public void SetFileName(string name){
            reName = name;
        }

        
        public void InitWatcher()
        {
            
            timerstimer.Interval = 200;
            timerstimer.Elapsed += Timerstimer_Elapsed;

            string Today = DateTime.Now.ToString("yyyy") + "_" + DateTime.Now.ToString("MM") + "_" + DateTime.Now.ToString("dd");
            
            System.IO.FileSystemWatcher watcher = new System.IO.FileSystemWatcher();
            watcher.Path = @"C:\Users\kim.woohyun\Documents\"+Today;

            watcher.NotifyFilter = System.IO.NotifyFilters.FileName | System.IO.NotifyFilters.DirectoryName | System.IO.NotifyFilters.Size;

            watcher.Changed += new System.IO.FileSystemEventHandler(Watcher_Created);
            watcher.EnableRaisingEvents = true;

        }


        public void Watcher_Created(object sender, System.IO.FileSystemEventArgs e)
        {
            //this.view_event(true);

            fullPath = e.FullPath;
            path = System.IO.Path.GetDirectoryName(e.FullPath);
            exe = System.IO.Path.GetExtension(e.FullPath);
            num++;
            //SetFileCreate(true);
            //this.view_event(true);
            
            timerstimer.Start();
        }

        
        public void TimerStop()
        {
            timerstimer.Stop();
        }
        //public Boolean GetFileCreate() { return fileState; }
        //public void SetFileCreate(Boolean b) { fileState=b; }

        public void Timerstimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            System.IO.File.Move(fullPath, System.IO.Path.Combine(path, "No" + num.ToString() + "_" + reName + exe));
        }
    }

}