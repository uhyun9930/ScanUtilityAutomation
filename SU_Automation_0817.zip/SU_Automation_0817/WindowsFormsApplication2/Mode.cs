﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScanUtility_Automation
{
    abstract public class Mode
    {
       
        abstract public int GetModeNum();
        abstract public String[] GetSizeArray();
        abstract public String[] GetColorArray();
        abstract public String[] GetResolutionArray();
        abstract public String[] GetDataTypeArray();
        abstract public void SetSize(String size);
        abstract public void SetColor(String color);  
        abstract public void SetResolution(String resol);
        abstract public void SetDataType(String type);
        abstract public void SetDataTypeOption(String opt);
        abstract public uint GetSizeNum();
        abstract public uint GetColorNum();
        abstract public uint GetResolutionNum();
        abstract public uint GetDataTypeNum();
        abstract public uint GetDataTypeOptionNum();
        
    }

}
