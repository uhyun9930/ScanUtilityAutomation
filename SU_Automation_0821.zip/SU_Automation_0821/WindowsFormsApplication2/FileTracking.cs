﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Timers;
using System.Windows.Forms;
using System.Threading;
namespace ScanUtility_Automation
{
    class FileTracking : SU_Automation
    {

        
        public delegate void view(string value, string type);
        public view view_event;

        public int number=0;
        public string reName;
        public string fullPath;
        public string filePath;
        public string fileExe;

        public FileTracking()
        {
            InitWatcher();
        }
        public void SetRename(string re)
        {
            reName = re;
        }

        public void InitWatcher()
        {

            //timerstimer.Interval = 200;
            //timerstimer.Elapsed += Timerstimer_Elapsed;

            System.IO.FileSystemWatcher watcher = new System.IO.FileSystemWatcher();
            string Today = DateTime.Now.ToString("yyyy") + "_" + DateTime.Now.ToString("MM") + "_" + DateTime.Now.ToString("dd");
            watcher.Path = @"C:\Users\kim.woohyun\Documents\2018_08_20";
            //watcher.Path = @"C:\Users\Woohyun\Desktop\논병아리";
            watcher.NotifyFilter = System.IO.NotifyFilters.FileName | System.IO.NotifyFilters.DirectoryName | System.IO.NotifyFilters.Size;
            watcher.Changed += new System.IO.FileSystemEventHandler(Watcher_Created);
            watcher.EnableRaisingEvents = true;

        }
        public void Watcher_Created(object sender, System.IO.FileSystemEventArgs e)
        {

            fullPath = e.FullPath;
            filePath = System.IO.Path.GetDirectoryName(e.FullPath);
            fileExe = System.IO.Path.GetExtension(e.FullPath);
            number++;
            MessageBox.Show("생성:"+e.FullPath);
            //timerstimer.Start();

            //Thread.Sleep(3000);
            //ResetFileName();
        }

        public void ResetFileName()
        {
            System.IO.File.Move(fullPath, System.IO.Path.Combine(path, "No" + number.ToString()+ "_" + reName + exe));
        }
       /*public void TimerStop()
        {
            timerstimer.Stop();
        }

        public void Timerstimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if(!System.IO.File.Exists(System.IO.Path.Combine(path, "No" +index.ToString()+ num.ToString() + "_" + reName + exe)))
            System.IO.File.Move(fullPath, System.IO.Path.Combine(path, "No" + index.ToString()+num.ToString()+"_" + reName + exe));
        }
        */


    }

}