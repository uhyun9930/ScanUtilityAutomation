﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;


namespace ScanUtility_Automation
{
    public partial class Terminate : Form
    {
        public delegate void FormSendDataHandler(Boolean run);
        public event FormSendDataHandler FormSendEvent;

        public Terminate()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.FormSendEvent(false);
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "Ready...";
            label2.Text = "";
        }

        public void label_change(int listnum, int totalList, int cnt, int totalCnt)
        {

            label1.Text = "row: " + listnum + "/" + totalList;
            label2.Text = "count: " + cnt+"/"+totalCnt;

        }
        
    }
}
