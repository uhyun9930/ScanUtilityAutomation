﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Excel = Microsoft.Office.Interop.Excel;
 

namespace ScanUtility_Automation
{
    class ExcelModule
    {
        Excel.Application excelApp;
        Excel.Workbook wb;
        Excel.Worksheet ws;
        object misValue;

        public ExcelModule()
        {
            excelApp = new Excel.Application();    //Excel 파일 생성
            
        }


        /// <summary>
        /// Excel파일 생성하기 
        /// </summary>
        public void CreateExcel()
        {
            misValue = System.Reflection.Missing.Value;
            wb = excelApp.Workbooks.Add(misValue);
        }

        /// <summary>
        /// Excel파일에서 읽어오기 
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public object[,] ReadFile(string path)
        {
            try {
                wb = excelApp.Workbooks.Open(path);
                ws = wb.Worksheets.get_Item(1) as Excel.Worksheet;
                Excel.Range rng = ws.UsedRange; 

                object[,] data = rng.Value;
                for (int r = 1; r <= data.GetLength(0); r++)
                {
                    for (int c = 1; c <= data.GetLength(1); c++)
                    {
                        if (data[r, c] == null)
                        {
                            continue;
                        }
                    }
                }
                return data;
            }



            catch (Exception ex)
            {
                throw ex;
            }
            
        }
        
        /// <summary>
        /// Excel파일 저장하기
        /// </summary>
        /// <param name="filepath"></param>
        public void SaveFile(string filepath)
        {
            string savefile = filepath;
            try
            {
                wb.SaveAs(@savefile, Excel.XlFileFormat.xlWorkbookNormal, misValue,
                misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive,
                misValue, misValue, misValue, misValue, misValue);
            }
            catch (System.Runtime.InteropServices.COMException ex)
            {
                return;
            }
        }


        public void QuitExcel()
        {
            wb.Close(true, misValue, misValue);
            excelApp.Quit();
            releaseObject(ws);
            releaseObject(wb);
            releaseObject(excelApp);
        }


        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
            }
            finally
            {
                GC.Collect();
            }
        }
    

    
    }
}
