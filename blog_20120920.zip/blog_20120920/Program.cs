﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace blog_20120920
{
    class Program : TestClass
    {
        static void Main(string[] args)
        {
            new Program();
        }
        Thread _thread;
        string inputData;
        public Program()
        {
            this.ExamEvent += new ClickEvent(Program_ExamEvent);
            _thread = new Thread(new ThreadStart(ExThread_Method));
            _thread.Start();
            while (true) {
                inputData = Console.ReadLine();
                if (inputData == "exit") {
                    _thread.Abort();
                    break;
                }
            }
            Console.WriteLine("\n\nProgram's processing is finished...\nPress any key...");
            Console.ReadLine();
        }
        public void ExThread_Method() {
            while (true) {
                if (inputData == "on") {
                    click();
                }
                Thread.Sleep(1000);
            }
        }
        void Program_ExamEvent(object sender, EventArgs args)
        {
            Console.WriteLine("이벤트 발생!");
        }

    }
    class TestClass
    {
        public delegate void ClickEvent(object sender, EventArgs args);
        public event ClickEvent ExamEvent;

        public void click()
        {
            EventArgs args = new EventArgs();
            ExamEvent(this, args);
        }
    }
}
