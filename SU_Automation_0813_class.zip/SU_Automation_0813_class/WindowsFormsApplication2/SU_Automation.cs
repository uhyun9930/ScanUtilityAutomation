﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Collections;
using autoDll;

namespace ScanUtility_Automation
{
    public partial class SU_Automation : Form
    {
        [DllImport("user32.dll")]
        public static extern void keybd_event(byte vk, byte scan, uint flags, int extrainfo);

        [DllImport("user32.dll")]
        public static extern uint FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll")]
        private static extern bool ShowWindowAsync(uint hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        public static extern uint FindWindowEx(uint hWnd1, uint hWnd2, string lpsz1, string lpsz2);

        [DllImport("user32.dll")]
        public static extern uint GetWindow(uint hWnd1, int uCmd);

        [DllImport("user32.dll")]
        public static extern uint SendMessage(uint hwnd, uint wMsg, uint wParam, uint lParam);

        [DllImport("user32.dll")]
        public static extern uint PostMessage(uint hwnd, uint wMsg, uint wParam, uint lParam);

        [DllImport("user32.dll")]
        public static extern void SetForegroundWindow(uint hWnd);

        [DllImport("user32.dll")]
        public static extern void BringWindowToTop(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        public static extern bool GetForegroundWindow(uint handle);

        [DllImport("user32.dll")]
        public static extern IntPtr SetParent(IntPtr child, IntPtr newParent);

        const int WM_LBUTTONDOWN = 0x0201;
        const int WM_LBUTTONUP = 0x0202;
        const int WM_KEYDOWN = 0x0100;
        const int BM_CLICK = 0x00F5; //버튼 클릭 
        const int TCM_SETCURFOCUS = 0x1330; //상위 탭

        //handle = FindWindowEx(handle, 0, "SysTabControl32", null);
        //SendMessage(handle, TCM_SETCURFOCUS, 2, 0);상위 탭 클릭 됨 


        const int CB_SETCURSEL = 0x014E; // ComboBox Index변경
        const int CB_GETLBTEXT = 0x0148;
        const int CB_SHOWDROPDOWN = 0x014f; // ComboBox 클릭
        const int VK_UP = 0x26; //UP ARROW KEY
        const int VK_RIGHT = 0x27; //RIGHT ARROW KEY
        const int VK_DOWN = 0x28; //DOWN ARROW KEY
        const int VK_ESCAPE = 0x1B; //ESC KEY
        const int VK_F4 = 0x73; //F4 KEY
        const int KEYEVENTF_KEYUP = 0x0002;
        const int VK_RETURN = 0x0D; //ENTER KEY

        const int WM_SETCURSOR = 0x0020;

        const int TAB_KEY = 9;
        const int WM_SETTEXT = 0x000C;

        const int GW_HWNDFIRST = 0;
        const int GW_HWNDLAST = 1;
        const int GW_HWNDNEXT = 2;
        const int GW_HWNDPREV = 3;
        const int GW_OWNER = 4;
        const int GW_CHILD = 5;

        const uint KEYEVENTF_EXTENDEDKEY = 0x00001;

        private const int SW_SHOWNORMAL = 1;
        private const int SW_SHOWMINIMIZED = 2;
        private const int SW_SHOWMAXIMIZED = 3;
        uint handle;

        public Boolean run = true; //Thread Flag

        String[] v = new string[8];

        Form1 form1 = new Form1(); // 종료 창 생성
        Thread spThread;

        Mode m;

        public SU_Automation()
        {

            InitializeComponent();
            comboBox1.SelectedItem = "Document";
            comboBox2.SelectedItem = "평판 유리";
            comboBox3.SelectedItem = "A4";
            comboBox4.SelectedItem = "컬러";
            comboBox5.SelectedItem = "300dpi";
            comboBox6.SelectedItem = "TIFF";
            comboBox7.SelectedItem = "표준";
            textBox1.SelectedText = "1";
            //ComboBox Default값 설정


            System.Diagnostics.Process abc = new System.Diagnostics.Process();
            abc.StartInfo.UseShellExecute = false;
            abc.StartInfo.FileName = "C:\\Program Files\\Canon\\MF Scan Utility\\MFSCANUTILITY.exe";
            abc.Start(); // SCAN Utility 창 띄우기

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) //모드
        {

            ArrayList arrType = new ArrayList();

            Object selectedItem = comboBox1.SelectedItem;
            v[0] = selectedItem.ToString();

            SelectMode(v[0]);
            ComboboxSetting(v[0]); //모드별 콤보박스 세팅
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e) //원고 입력방식
        {
            Object selectedItem = comboBox2.SelectedItem;
            v[1] = selectedItem.ToString();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e) //용지크기
        {
            Object selectedItem = comboBox3.SelectedItem;
            v[2] = selectedItem.ToString();

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e) //컬러모드
        {
            Object selectedItem = comboBox4.SelectedItem;
            v[3] = selectedItem.ToString();
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e) //해상도
        {
            Object selectedItem = comboBox5.SelectedItem;
            v[4] = selectedItem.ToString();
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e) //데이터 형식
        {

            Object selectedItem = comboBox6.SelectedItem;
            v[5] = selectedItem.ToString();

            if (v[5] == "JPEG/Exif") //데이터형식에 따라 데이터형식별 옵션이 달라짐
            {
                comboBox7.Enabled = true;
                comboBox7.Items.Clear();
                this.comboBox7.Items.AddRange(new object[] { "낮음", "표준", "높음" });
                comboBox7.SelectedItem = "표준";
            }
            else if (v[5] == "PDF(단일 페이지)" || v[5] == "PDF")
            {
                comboBox7.Enabled = true;
                comboBox7.Items.Clear();
                this.comboBox7.Items.AddRange(new object[] { "표준", "높음" });
                comboBox7.SelectedItem = "표준";
            }
            else //JPEG/Exif, PDF이외의 항목은 옵션X
            {
                comboBox7.Items.Clear();
                comboBox7.Enabled = false; //콤보박스 비활성화
                v[6] = "없음";
            }

        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e) //데이터 형식별 옵션
        {
            Object selectedItem = comboBox7.SelectedItem;
            v[6] = selectedItem.ToString();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Object selectedItem = textBox1.Text;
            v[7] = selectedItem.ToString();
        }

        private void button1_Click(object sender, EventArgs e) //listBox [추가]버튼
        {
            listBox1.Items.Add(v[0] + ", " + v[1] + ", " + v[2] + ", " + v[3] + ", " + v[4] + ", " + v[5] + ", " + v[6] + ", " + v[7]);
        }

        private void button2_Click(object sender, EventArgs e) //listBox [삭제]버튼
        {
            int index;
            if (listBox1.SelectedIndex > -1)
            {
                index = listBox1.SelectedIndex;
                listBox1.Items.RemoveAt(index);
            } //선택되지 않았을 때 (혹은 listbox에 아무것도 없을 때) 에러메세지 무시

        }

        private void DieaseUpdateEventMethod(Boolean sender)
        {
            //Form1에서 델리게이트로 이벤트 발생하면 현재 함수 Call
            run = sender;
            spThread.Abort();
            //spThread.Interrupt();
        }


        public void button3_Click(object sender, EventArgs e) //설정 완료 후 [확인]버튼
        {
            checkStateOfScanUtility(); //Scan Utility 창 없으면 생성 
            run = true; //스레드 실행 명령 
            form1 = new Form1(); // 종료 창 생성
            form1.Visible = true;
            form1.FormSendEvent += new Form1.FormSendDataHandler(DieaseUpdateEventMethod);

            try
            {
                spThread = new Thread(new ThreadStart(Scanning));
                spThread.Start();


            }

            catch (ThreadInterruptedException)
            {

            }


        }
        public void SelectMode(String mode)
        {
            switch (mode)
            {

                case "Document":
                    m = new DocumentMode();
                    break;
                case "Photo":
                    m = new PhotoMode();
                    break;
                case "Custom":
                    m = new CustomMode();
                    break;
                case "Stitch":
                    m = new StitchMode();
                    break;
                case "ScanGear":
                    m = new ScanGearMode();
                    break;
                case "OCR":
                    m = new OCRMode();
                    break;
                case "E-mail":
                    m = new EmailMode();
                    break;
            }



        }

        private void Scanning()
        {
            //제품명 초기설정 해야함 


            for (int i = 0; i < listBox1.Items.Count; i++)
            {


                String s = listBox1.Items[i].ToString();
                String[] words = s.Split(new string[] { ", " }, StringSplitOptions.None); //listBox의 설정 내용 split후 변수에 저장

                /*v[0] = words[0];
                v[1] = words[1];
                v[2] = words[2];
                v[3] = words[3];
                v[4] = words[4];
                v[5] = words[5];
                v[6] = words[6];
                v[7] = words[7];*/
                int cnt = Int32.Parse(words[7]);


                ////////////////////////////////////////////////////////
                // 모드 선택  ///////////////////////////////////////////
                /////////////////////////////////////////////////////////

                SelectMode(words[0]);




                for (int j = 0; j < cnt; j++)
                {

                    handle = FindWindow("#32770", "Canon MF Scan Utility");
                    SetForegroundWindow(handle);
                    handle = FindWindowEx(handle, 0, "button", "설정(&S)...");

                    PostMessage(handle, BM_CLICK, 0, 0);
                    //Scan Utility창의 설정버튼 클릭

                    do
                    {
                        Thread.Sleep(100);
                        handle = 0;
                        handle = FindWindow("#32770", "설정(문서 스캔)");

                    } while (handle == 0);
                    //상세 설정창 뜰때까지 기다림



                    SetForegroundWindow(handle);
                    handle = FindWindowEx(handle, 0, "#32770", null);


                    int num = m.GetModeNum(); //각 모드별 지정된 번호

                    SetMode(num); // 번호로 모드 setting

                    SetInput(words[1], m); // 원고 입력방식 : 평판유리 

                    SetSize(words[0], words[2], m); // 용지 크기

                    SetColorMode(words[0], words[3], m); // 컬러 모드 

                    SetResolution(words[0], words[4], m); // 해상도 

                    SetDataType(words[5], m); // 데이터 형식

                    keybd_event((byte)VK_F4, 0, KEYEVENTF_EXTENDEDKEY | 0, 0);
                    
                    Thread.Sleep(4000);
                    SetDataTypeOption(words[5], words[6]);

                    Thread.Sleep(1000);


                    OKButton_Click(words[0]);
                    Thread.Sleep(1000);

                    SetStart(words[0]);


                    if (words[0] == "ScanGear")
                    {
                        do
                        {
                            Thread.Sleep(1000);
                            handle = 0;
                            handle = FindWindow(null, "ScanGear MF");
                        }
                        while (handle == 0);
                        //ScanGear창이 뜰때까지 while


                        handle = FindWindowEx(handle, 0, "#32770", "ScanGear MF");
                        handle = FindWindowEx(handle, 0, "#32770", "고급 모드");

                        SetForegroundWindow(handle);

                        //데이터형식, PDF압축형식 설정 위에서 완료
                        SetSize(words[0], words[2], m); // 용지 크기

                        Thread.Sleep(1000);

                        keybd_event((byte)VK_F4, 0, KEYEVENTF_EXTENDEDKEY | 0, 0);
                        Thread.Sleep(1000);

                        SetColorMode(words[0], words[3], m); // 컬러 모드 
                        SetResolution(words[0], words[4], m); // 해상도 

                        Thread.Sleep(1000);

                        handle = FindWindowEx(handle, 0, "CMyBmpButton2_Class", "스캔(&S)");
                        PostMessage(handle, WM_LBUTTONDOWN, 0, 0);
                        Thread.Sleep(100);
                        PostMessage(handle, WM_KEYDOWN, VK_RETURN, 0);
                        Thread.Sleep(100);
                    }

                    /////////////////////////////////////////////////////////설정창 유무 
                    /*
                    String[] arr = m.GetDataTypeArray();
                    String[,] arr2 = m.GetWaitArray();
                    String checkScanSettingW = "", checkSaveSettingW = "";
                    


                    for (int a = 0; a < arr.Length; a++)
                    {
                        if (words[5] == arr[a])
                        {
                            checkScanSettingW = arr2[a, 0];
                            checkSaveSettingW = arr2[a, 1];
                            break;
                        }
                    }
                    
                    /////////////////////////////////////////////////////////스캔설정창

                    do
                    {
                        SetForegroundWindow(handle);
                        Thread.Sleep(1000);
                        handle = 0;
                        handle = FindWindow("#32770", "스캔 완료");

                    }
                    while (handle == 0 && checkScanSettingW == "O");

                    if (checkScanSettingW == "O")
                    {
                        SetForegroundWindow(handle);
                        handle = FindWindowEx(handle, 0, "Button", "종료");
                        PostMessage(handle, BM_CLICK, 0, 0);
                    }

                    /////////////////////////////////////////////////////////저장설정창

                    do
                    {
                        SetForegroundWindow(handle);
                        Thread.Sleep(1000);
                        handle = 0;
                        handle = FindWindow("#32770", "저장 설정");

                    }
                    while (handle == 0 && checkSaveSettingW == "O");

                    if (checkSaveSettingW == "O")
                    {
                        SetForegroundWindow(handle);
                        Thread.Sleep(100);
                        handle = FindWindowEx(handle, 0, "Button", "확인");
                        PostMessage(handle, BM_CLICK, 0, 0);
                        Thread.Sleep(2000);
                    }
                    */



                }
                /*
                if (words[5] == "PDF")//pdf설정 제외.  pdf일시에만 스캔완료 창이 뜨고 저장설정창이 뜸 (사용자정의,스캔기어는 저장설정창 안뜸)

                //pdf단일페이지 (문서,사진,전자메일(어떻게 처리하지?))- 저장설정창 뜸
                {
                    do
                    {
                        Thread.Sleep(1000);
                        handle = 0;
                        handle = FindWindow("#32770", "스캔 완료");

                    }
                    while (handle == 0);

                }


                else
                {

                    Thread.Sleep(20000);
                    handle = FindWindow("#32770", "스캔 완료");
                    handle = FindWindowEx(handle, 0, "Button", "종료");
                    PostMessage(handle, BM_CLICK, 0, 0);

                }


                if (words[0] == "Photo" || words[0] == "OCR" || words[0] == "E-mail")
                {
                    do///저장 설정창은 Mode가 사진,OCR,전자메일 일 경우에만 뜨기때문에 따로 처리해야 함
                    {
                        Thread.Sleep(1000);
                        handle = 0;
                        handle = FindWindow("#32770", "저장 설정");

                    }
                    while (handle == 0);

                    SetForegroundWindow(handle);
                    Thread.Sleep(100);
                    handle = FindWindowEx(handle, 0, "Button", "확인");
                    PostMessage(handle, BM_CLICK, 0, 0);
                    Thread.Sleep(2000);
                }
                */

            }


            form1.Close();

        }


        public void checkStateOfScanUtility() // SCAN Utility 창이 열려있는지 확인
        {
            handle = 0;
            handle = FindWindow("#32770", "Canon MF Scan Utility");
            if (handle == 0)
            {
                System.Diagnostics.Process abc = new System.Diagnostics.Process();
                abc.StartInfo.UseShellExecute = false;
                abc.StartInfo.FileName = "C:\\Program Files\\Canon\\MF Scan Utility\\MFSCANUTILITY.exe";
                abc.Start(); // SCAN Utility 창 띄우기
            }
            Thread.Sleep(1000);
        }


        public void ComboboxSetting(String mode)
        {
            ////////////////////////////////////////////////////////////////////
            //콤보박스 값 string배열로 받아넣기 //////////////////////////////////
            ////////////////////////////////////////////////////////////////////


            comboBox3.Enabled = true;//용지 크기 설정
            comboBox3.Items.Clear();
            String[] size = m.GetSizeArray();
            comboBox3.Items.AddRange(size);
            comboBox3.SelectedItem = "A4";

            comboBox4.Enabled = true;//컬러 모드 설정
            comboBox4.Items.Clear();
            String[] col = m.GetColorArray();
            comboBox4.Items.AddRange(col);
            comboBox4.SelectedItem = "컬러";

            comboBox5.Enabled = true;//해상도 설정
            comboBox5.Items.Clear();
            String[] res = m.GetResolutionArray();
            comboBox5.Items.AddRange(res);
            comboBox5.SelectedItem = "300dpi";


            comboBox6.Enabled = true; //데이터 형식 설정
            comboBox6.Items.Clear();
            String[] type = m.GetDataTypeArray();
            comboBox6.Items.AddRange(type);
            comboBox6.SelectedItem = "JPEG/Exif";




            /*
            comboBox3.Enabled = true;//용지 크기 설정
            comboBox3.Items.Clear();
            this.comboBox3.Items.AddRange(new object[] {
            "A4","A5","A5R","A6", "A6R","Letter","Statement", "StatementR","명함 용지","전체 평판 크기"});
            comboBox3.SelectedItem = "A4";
           

            comboBox4.Enabled = true;//컬러 모드 설정
            comboBox4.Items.Clear();
            this.comboBox4.Items.AddRange(new object[] {
            "컬러","회색조","흑백"});
            comboBox4.SelectedItem = "컬러";


            comboBox5.Enabled = true;//해상도 설정
            comboBox5.Items.Clear();
            this.comboBox5.Items.AddRange(new object[] {
            "75dpi","100dpi","150dpi","200dpi","300dpi","400dpi","600dpi"});
            comboBox5.SelectedItem = "300dpi";


            comboBox6.Enabled = true; //데이터 형식 설정
            comboBox6.Items.Clear();
            this.comboBox6.Items.AddRange(new object[] {
            "JPEG/Exif","TIFF", "PNG","PDF(단일 페이지)", "PDF"});
            comboBox6.SelectedItem = "JPEG/Exif";




            if (mode == "ScanGear")
            {
                comboBox3.Enabled = true; //용지 크기 설정
                comboBox3.Items.Clear();
                this.comboBox3.Items.AddRange(new object[] {
                    "A4","A5","A5R","A6", "A6R", "Letter","Statement","StatementR","4x6","4x6R","명함","전체 평판 크기"});
                comboBox3.SelectedItem = "A4";

                comboBox4.Enabled = true; //컬러 모드 설정
                comboBox4.Items.Clear();
                this.comboBox4.Items.AddRange(new object[] {
                    "흑백","회색조","컬러","고급 텍스트"});
                comboBox4.SelectedItem = "컬러";

                comboBox5.Enabled = true; //해상도 설정
                comboBox5.Items.Clear();
                this.comboBox5.Items.AddRange(new object[] {
                   "50dpi", "75dpi","100dpi","150dpi","200dpi","300dpi","400dpi","600dpi"});
                comboBox5.SelectedItem = "300dpi";

            }
            if (mode == "Document")
            {
                comboBox6.Enabled = true;//데이터 형식 설정
                comboBox6.Items.Clear();
                this.comboBox6.Items.AddRange(new object[] {
            "TIFF", "PNG","PDF(단일 페이지)", "PDF"});
                comboBox6.SelectedItem = "TIFF";
            }

            if (mode == "OCR")
            {
                comboBox5.Enabled = true;//해상도 설정
                comboBox5.Items.Clear();
                this.comboBox5.Items.AddRange(new object[] {
            "300dpi","400dpi"});
                comboBox5.SelectedItem = "300dpi";

                comboBox6.Enabled = true;//데이터 형식 설정
                comboBox6.Items.Clear();
                this.comboBox6.Items.AddRange(new object[] {
            "JPEG/Exif","TIFF", "PNG"});
                comboBox6.SelectedItem = "JPEG/Exif";
            }


             */

        }

        public void SetMode(int modeNum)
        {
            for (int i = 0; i < modeNum; i++)
            {
                keybd_event((byte)VK_RIGHT, 0, KEYEVENTF_EXTENDEDKEY | 0, 0);
                Thread.Sleep(500);
            }
        }


        /*
        public void SetMode(String mode) // 모드 설정 - 키보드 오른쪽 화살표버튼으로 이동, 화면이 맨앞에 위치해야 함
        {
            switch (mode)
            {
                case "Document":
                    break;
                case "Photo":
                    for (int i = 0; i < 3; i++)
                    {
                        keybd_event((byte)VK_RIGHT, 0, KEYEVENTF_EXTENDEDKEY | 0, 0);
                        Thread.Sleep(500);

                    };
                    Thread.Sleep(1000);
                    break;
                case "Custom":
                    for (int i = 0; i < 4; i++)
                    {
                        keybd_event((byte)VK_RIGHT, 0, KEYEVENTF_EXTENDEDKEY | 0, 0);
                        Thread.Sleep(500);
                    };
                    Thread.Sleep(1000);
                    break;
                case "Stitch":
                    for (int i = 0; i < 5; i++)
                    {
                        keybd_event((byte)VK_RIGHT, 0, KEYEVENTF_EXTENDEDKEY | 0, 0);
                        Thread.Sleep(500);
                    };
                    Thread.Sleep(2000);
                    break;
                case "ScanGear":
                    for (int i = 0; i < 6; i++)
                    {
                        keybd_event((byte)VK_RIGHT, 0, KEYEVENTF_EXTENDEDKEY | 0, 0);
                        Thread.Sleep(500);
                    };
                    Thread.Sleep(2000);
                    break;
                case "OCR":
                    for (int i = 0; i < 7; i++)
                    {
                        keybd_event((byte)VK_RIGHT, 0, KEYEVENTF_EXTENDEDKEY | 0, 0);
                        Thread.Sleep(500);
                    };

                    Thread.Sleep(2000);
                    break;
                case "E-mail":
                    for (int i = 0; i < 8; i++)
                    {
                        keybd_event((byte)VK_RIGHT, 0, KEYEVENTF_EXTENDEDKEY | 0, 0);
                        Thread.Sleep(500);
                    };
                    Thread.Sleep(2000);
                    break;
            }
        }
        */

        public void SetInput(String input, Mode mode) //압판 스캔 자동화시 선택지는 평판 유리 한정
        {
            uint n_handle;
            n_handle = FindWindowEx(handle, 0, "Static", "스캔 방법(&S):");
            n_handle = GetWindow(n_handle, GW_HWNDNEXT);
            n_handle = FindWindowEx(n_handle, 0, "ComboBox", null);

            uint r = 0;
            String[] sel = mode.GetSizeArray();
            for (r = 0; r < sel.Length; r++)
            {
                if (input == sel[r])
                    break;
            }

            PostMessage(n_handle, CB_SETCURSEL, r, 0);

        }

        public void SetColorMode(String selectedMode, String col, Mode mode) // 컬러 모드 설정 
        {
            uint n_handle;

            if (selectedMode == "ScanGear")
            {

                n_handle = FindWindowEx(handle, 0, "Static", "컬러 모드:");
                n_handle = GetWindow(n_handle, GW_HWNDNEXT);
                /*switch (mode)
                {
                    case "흑백": PostMessage(n_handle, CB_SETCURSEL, 0, 0);
                        break;
                    case "회색조": PostMessage(n_handle, CB_SETCURSEL, 1, 0);
                        break;
                    case "컬러": PostMessage(n_handle, CB_SETCURSEL, 2, 0);
                        break;
                    case "고급 텍스트": PostMessage(n_handle, CB_SETCURSEL, 3, 0);
                        break;
                }*/

            }
            else
            {
                n_handle = FindWindowEx(handle, 0, "Static", "컬러 모드(&C):");
                n_handle = GetWindow(n_handle, GW_HWNDNEXT);
                n_handle = FindWindowEx(n_handle, 0, "ComboBox", null);
                /*switch (col)
                {
                    case "컬러": PostMessage(n_handle, CB_SETCURSEL, 0, 0);
                        break;
                    case "회색조": PostMessage(n_handle, CB_SETCURSEL, 1, 0);
                        break;
                    case "흑백": PostMessage(n_handle, CB_SETCURSEL, 2, 0);
                        break;
                }*/
            }

            uint r = 0;
            String[] sel = mode.GetColorArray();
            for (r = 0; r < sel.Length; r++)
            {
                if (col == sel[r])
                    break;
            }
            PostMessage(n_handle, CB_SETCURSEL, r, 0);
        }


        /* public void SetSize(uint num, Mode mode)
         {
             uint n_handle;
             n_handle = FindWindowEx(handle, 0, "Static", "용지 크기(&E):");
             n_handle = GetWindow(n_handle, GW_HWNDNEXT);
             n_handle = FindWindowEx(n_handle, 0, "ComboBox", null);
             PostMessage(n_handle, CB_SETCURSEL, num, 0);
         }*/


        public void SetSize(String selectedMode, String size, Mode mode) // 입력 크기 설정
        {
            uint n_handle;


            if (selectedMode == "ScanGear")
            {
                n_handle = FindWindowEx(handle, 0, "Static", "입력 크기:");
                n_handle = GetWindow(n_handle, GW_HWNDNEXT);
                /*switch (size)
                {
                    case "A4": num = 0;
                        break;
                    case "A5": num = 1;
                        break;
                    case "A5R": num = 2;
                        break;
                    case "A6": num = 3;
                        break;
                    case "A6R": num = 4;
                        break;
                    case "Letter": num = 5;
                        break;
                    case "Statement": num = 6;
                        break;
                    case "StatementR": num = 7;
                        break;
                    case "4x6": num = 8;
                        break;
                    case "4x6R": num = 9;
                        break;
                    case "명함": num = 10;
                        break;
                    case "전체 평판 크기": num = 11;
                        break;
                }
                PostMessage(n_handle, CB_SETCURSEL, num, 0);
                Thread.Sleep(500);
                PostMessage(n_handle, CB_SHOWDROPDOWN, 2, 0);*/

            }
            else
            {

                n_handle = FindWindowEx(handle, 0, "Static", "용지 크기(&E):");
                n_handle = GetWindow(n_handle, GW_HWNDNEXT);
                n_handle = FindWindowEx(n_handle, 0, "ComboBox", null);
                /*switch (size)
                {
                    case "A4": num = 0;
                        break;
                    case "A5": num = 1;
                        break;
                    case "A5R": num = 2;
                        break;
                    case "A6": num = 3;
                        break;
                    case "A6R": num = 4;
                        break;
                    case "Letter": num = 5;
                        break;
                    case "Statement": num = 6;
                        break;
                    case "StatementR": num = 7;
                        break;
                    case "명함 용지": num = 8;
                        break;
                    case "전체 평판 크기": num = 9;
                        break;
                    case "사용자 정의": num = 10;
                        break;
                }
                PostMessage(n_handle, CB_SETCURSEL, num, 0);*/
            }
            uint r = 0;
            String[] sel = mode.GetSizeArray();
            for (r = 0; r < sel.Length; r++)
            {
                if (size == sel[r])
                    break;
            }
            PostMessage(n_handle, CB_SETCURSEL, r, 0);

        }
        public void SetResolution(String selectedMode, String resol, Mode mode) // 해상도 설정
        {
            uint n_handle;


            if (selectedMode == "ScanGear")
            {

                n_handle = FindWindowEx(handle, 0, "Static", "출력 해상도:");
                n_handle = GetWindow(n_handle, GW_HWNDNEXT);
                /*switch (resol)
                {
                    case "50dpi": num = 0;
                        break;
                    case "75dpi": num = 1;
                        break;
                    case "100dpi": num = 2;
                        break;
                    case "150dpi": num = 3;
                        break;
                    case "200dpi": num = 4;
                        break;
                    case "300dpi": num = 5;
                        break;
                    case "400dpi": num = 6;
                        break;
                    case "600dpi": num = 7;
                        break;
                }*/
            }
            else
            {

                n_handle = FindWindowEx(handle, 0, "Static", "해상도(&R):");
                n_handle = GetWindow(n_handle, GW_HWNDNEXT);
                n_handle = FindWindowEx(n_handle, 0, "ComboBox", null);
                /*
                switch (resol)
                {
                    case "75dpi": num = 0;
                        break;
                    case "100dpi": num = 1;
                        break;
                    case "150dpi": num = 2;
                        break;
                    case "200dpi": num = 3;
                        break;
                    case "300dpi": num = 4;
                        break;
                    case "400dpi": num = 5;
                        break;
                    case "600dpi": num = 6;
                        break;
                }*/

            }

            uint r = 0;
            String[] sel = mode.GetResolutionArray();
            for (r = 0; r < sel.Length; r++)
            {
                if (resol == sel[r])
                    break;
            }
            PostMessage(n_handle, CB_SETCURSEL, r, 0);

        }
        public void SetDataType(String type, Mode mode)
        {
            uint n_handle;
            n_handle = FindWindowEx(handle, 0, "Static", "데이터 형식(&O):");
            n_handle = GetWindow(n_handle, GW_HWNDNEXT);
            n_handle = FindWindowEx(n_handle, 0, "ComboBox", null);

            uint r = 0;
            String[] sel = mode.GetDataTypeArray();
            for (r = 0; r < sel.Length; r++)
            {
                if (type == sel[r])
                    break;
            }

            /*if (v[0] == "Document")
            {
                switch (type)
                {
                    case "TIFF": num = 0;
                        break;
                    case "PNG": num = 1;
                        break;
                    case "PDF(단일 페이지)": num = 2;
                        break;
                    case "PDF": num = 3;
                        break;
                }

            }
            else
            {
                switch (type)
                {
                    case "JPEG/Exif": num = 0;
                        break;
                    case "TIFF": num = 1;
                        break;
                    case "PNG": num = 2;
                        break;
                    case "PDF(단일 페이지)": num = 3;
                        break;
                    case "PDF": num = 4;
                        break;
                }
            }
            */
            PostMessage(n_handle, CB_SETCURSEL, r, 0);
            Thread.Sleep(500);

            PostMessage(n_handle, CB_SHOWDROPDOWN, 2, 0);
            SetForegroundWindow(n_handle);
        }


        public void SetDataTypeOption(String type, String option)
        {
            uint n_handle;
            uint num = 0;

            if (type == "JPEG/Exif")
            {
                n_handle = FindWindowEx(handle, 0, "Static", "JPEG 이미지 품질(&J):");
                n_handle = GetWindow(n_handle, GW_HWNDNEXT);
                n_handle = FindWindowEx(n_handle, 0, "ComboBox", null);

                switch (option)
                {
                    case "낮음": num = 0;
                        break;
                    case "표준": num = 1;
                        break;
                    case "높음": num = 2;
                        break;

                }
                PostMessage(n_handle, CB_SETCURSEL, num, 0);
            }
            else if (type == "PDF(단일 페이지)")
            {
                n_handle = FindWindowEx(handle, 0, "Static", "PDF 압축(&P):");
                n_handle = GetWindow(n_handle, GW_HWNDNEXT);
                n_handle = FindWindowEx(n_handle, 0, "ComboBox", null);
                switch (option)
                {
                    case "표준": num = 0;
                        break;
                    case "높음": num = 1;
                        break;
                }

                PostMessage(n_handle, CB_SETCURSEL, num, 0);
            }
        }


        public void OKButton_Click(String mode) // 설정 끝난 후 최종적으로 확인버튼 클릭
        {
            uint n_handle;
            switch (mode)
            {
                case "Document":
                    handle = FindWindow("#32770", "설정(문서 스캔)");
                    break;
                case "Photo":
                    handle = FindWindow("#32770", "설정(사진 스캔)");
                    break;
                case "Custom":
                    handle = FindWindow("#32770", "설정(사용자 정의 스캔)");
                    break;
                case "Stitch":
                    handle = FindWindow("#32770", "설정(스캔 및 스티치)");
                    break;
                case "ScanGear":
                    handle = FindWindow("#32770", "설정(ScanGear)");
                    break;
                case "OCR":
                    handle = FindWindow("#32770", "설정(OCR)");
                    break;
                case "E-mail":
                    handle = FindWindow("#32770", "설정(전자 메일)");
                    break;

            }
            n_handle = FindWindowEx(handle, 0, "button", "확인");
            PostMessage(n_handle, BM_CLICK, 0, 0);
            Thread.Sleep(1000);
        }

        public void SetStart(String mode)
        {
            uint n_handle = FindWindow("#32770", "Canon MF Scan Utility");
            switch (mode)
            {
                case "Document":
                    n_handle = FindWindowEx(n_handle, 0, "button", "문서");
                    break;
                case "Photo":
                    n_handle = FindWindowEx(n_handle, 0, "button", "사진");
                    break;
                case "Custom":
                    n_handle = FindWindowEx(n_handle, 0, "button", "사용자 정의");
                    break;
                case "Stitch":
                    n_handle = FindWindowEx(n_handle, 0, "button", "스티치");
                    break;
                case "ScanGear":
                    n_handle = FindWindowEx(n_handle, 0, "button", "ScanGear");
                    break;
                case "OCR":
                    n_handle = FindWindowEx(n_handle, 0, "button", "OCR");
                    break;
                case "E-mail":
                    n_handle = FindWindowEx(n_handle, 0, "button", "전자 메일");
                    break;

            }
            PostMessage(n_handle, BM_CLICK, 0, 0);
            Thread.Sleep(1000);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e) //취소버튼
        {
            //uint hwnd = FindWindow("#32770", "Canon MF Scan Utility");
            //SendMessage(hwnd, 0x0010, 0,0);

            run = false;
            spThread.Abort();

            foreach (Process process in Process.GetProcesses())
            {
                if (process.ProcessName.StartsWith("MFSCANUTILITY.exe"))
                {
                    process.Kill();
                }
            }

            Close();
        }

        private void SU_Automation_Load(object sender, EventArgs e)
        {

        }

        private void SU_Automation_FormClosing(object sender, FormClosingEventArgs e)
        {
            //폼을 닫을건지 취소 할 것인지 결정
            DialogResult dr = MessageBox.Show("종료하시겠습니까?",
            "종료확인",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Information);

            if (dr == DialogResult.No)
            {
                e.Cancel = true; //취소
            }
        }

    }
}

