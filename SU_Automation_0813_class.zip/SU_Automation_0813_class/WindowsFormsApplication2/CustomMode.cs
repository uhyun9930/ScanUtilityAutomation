﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScanUtility_Automation
{
    class CustomMode : Mode
    {
        public CustomMode()
        { 
            
        }

        public int modeNum = 4;

        public String[] sizeArray = { "A4", "A5", "A5R", "A6", "A6R", "Letter", "Statement", "StatementR", "명함 용지", "전체 평판 크기" };
        public String[] colorArray = { "컬러", "회색조", "흑백" };
        public String[] resolutionArray = { "75dpi", "100dpi", "150dpi", "200dpi", "300dpi", "400dpi", "600dpi" };
        public String[] dataTypeArray = { "JPEG/Exif", "TIFF", "PNG", "PDF(단일 페이지)", "PDF" };
        public String[,] waitArray = { { "N", "N" }, { "N", "N" }, { "N", "N" }, { "N", "N" }, { "O", "N" } };

        public override int GetModeNum()
        {
            return modeNum;
        }

        public override String[] GetSizeArray()
        {
            return sizeArray;
        }

        public override String[] GetColorArray()
        {
            return colorArray;
        }

        public override String[] GetResolutionArray()
        {
            return resolutionArray;
        }

        public override String[] GetDataTypeArray()
        {
            return dataTypeArray;
        }
        public override String[,] GetWaitArray()
        {
            return waitArray;
        }
    }
}
