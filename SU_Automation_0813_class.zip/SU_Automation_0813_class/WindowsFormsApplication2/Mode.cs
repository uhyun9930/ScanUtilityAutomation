﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScanUtility_Automation
{
    abstract public class Mode
    {
       
        abstract public int GetModeNum();
        abstract public String[] GetSizeArray();
        abstract public String[] GetColorArray();
        abstract public String[] GetResolutionArray();
        abstract public String[] GetDataTypeArray();
        abstract public String[,] GetWaitArray();
    }

}
