﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScanUtility_Automation
{
    class OCRMode : Mode
    {
        public OCRMode()
        { 
            
        }

        public int modeNum = 7;

        public String[] sizeArray = { "A4", "A5", "A5R", "A6", "A6R", "Letter", "Statement", "StatementR", "명함 용지", "전체 평판 크기" };
        public String[] colorArray = { "컬러", "회색조", "흑백" };
        public String[] resolutionArray = { "300dpi", "400dpi" };
        public String[] dataTypeArray = { "JPEG/Exif", "TIFF", "PNG" };
        public String[,] waitArray = { { "N", "O" }, { "N", "O" }, { "N", "O" } };

        public override int GetModeNum()
        {
            return modeNum;
        }

        public override String[] GetSizeArray()
        {
            return sizeArray;
        }

        public override String[] GetColorArray()
        {
            return colorArray;
        }

        public override String[] GetResolutionArray()
        {
            return resolutionArray;
        }

        public override String[] GetDataTypeArray()
        {
            return dataTypeArray;
        }
        public override String[,] GetWaitArray()
        {
            return waitArray;
        }
    }
}
