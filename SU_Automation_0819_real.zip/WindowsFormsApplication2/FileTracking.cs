﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;
using System.Windows.Forms;
namespace ScanUtility_Automation
{
    class FileTracking : SU_Automation
    {

        
        //public delegate void view(string value, string type);
        //public view view_event;
        System.Timers.Timer timerstimer = new System.Timers.Timer();

        public int num, index;
        public string reName;
        public string fullPath;
        public string path;
        public string exe;

        public FileTracking()
        {
            InitWatcher();
        }

        public void SetNumber(int i)
        {
            index = i;
        }

        public void SetRename(string re, int cnt)
        {
            reName = re;
            num = cnt;
        }

        public void InitWatcher()
        {

            timerstimer.Interval = 200;
            timerstimer.Elapsed += Timerstimer_Elapsed;

            System.IO.FileSystemWatcher watcher = new System.IO.FileSystemWatcher();
            string Today = DateTime.Now.ToString("yyyy") + "_" + DateTime.Now.ToString("MM") + "_" + DateTime.Now.ToString("dd");
            //watcher.Path = @"C:\Users\kim.woohyun\Documents\"+Today;

            watcher.Path = @"C:\Users\Woohyun\Desktop\논병아리";
            watcher.NotifyFilter = System.IO.NotifyFilters.FileName | System.IO.NotifyFilters.DirectoryName | System.IO.NotifyFilters.Size;
            watcher.Changed += new System.IO.FileSystemEventHandler(Watcher_Created);
            watcher.EnableRaisingEvents = true;

        }
        public void Watcher_Created(object sender, System.IO.FileSystemEventArgs e)
        {

            fullPath = e.FullPath;
            path = System.IO.Path.GetDirectoryName(e.FullPath);
            exe = System.IO.Path.GetExtension(e.FullPath);
            //num++;
            timerstimer.Start();

        }

        public void TimerStop()
        {
            timerstimer.Stop();
        }

        public void Timerstimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if(!System.IO.File.Exists(System.IO.Path.Combine(path, "No" +index.ToString()+ num.ToString() + "_" + reName + exe)))
            System.IO.File.Move(fullPath, System.IO.Path.Combine(path, "No" + index.ToString()+num.ToString()+"_" + reName + exe));
        }



    }

}